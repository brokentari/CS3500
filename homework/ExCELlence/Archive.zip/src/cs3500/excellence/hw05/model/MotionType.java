package cs3500.excellence.hw05.model;

enum MotionType {
  MOVE,
  RESIZE,
  RECOLOR,
  STILL
}
