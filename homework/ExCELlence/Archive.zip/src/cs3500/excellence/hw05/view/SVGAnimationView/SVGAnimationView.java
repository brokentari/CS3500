package cs3500.excellence.hw05.view.SVGAnimationView;

import cs3500.excellence.hw05.model.AnimatedShape;
import cs3500.excellence.hw05.view.IView;
import java.util.ArrayList;

public class SVGAnimationView implements IView {

  @Override
  public void makeVisible() {

  }

  @Override
  public void refresh() {

  }

  @Override
  public void setShapes(ArrayList<AnimatedShape> as) {

  }
}
